import psycopg2
import requests
from datetime import datetime

# Database connection parameters
DB_NAME = "your_database_name"
DB_USER = "your_database_user"
DB_PASSWORD = "your_database_password"
DB_HOST = "your_database_host"
DB_PORT = "your_database_port"

# TimezoneDB API parameters
API_KEY = "your_timezone_db_api_key"
BASE_URL = "http://api.timezonedb.com/v2"

def create_tables(cursor):
    """Create necessary tables if they don't exist."""
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS TZDB_TIMEZONES (
            COUNTRYCODE VARCHAR(2),
            COUNTRYNAME VARCHAR(100),
            ZONENAME VARCHAR(100) PRIMARY KEY,
            GMTOFFSET NUMERIC,
            IMPORT_DATE TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS TZDB_ZONE_DETAILS (
            COUNTRYCODE VARCHAR(2),
            COUNTRYNAME VARCHAR(100),
            ZONENAME VARCHAR(100) PRIMARY KEY,
            GMTOFFSET NUMERIC,
            DST NUMERIC,
            ZONESTART NUMERIC,
            ZONEEND NUMERIC,
            IMPORT_DATE TIMESTAMP
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS TZDB_ERROR_LOG (
            ERROR_MESSAGE VARCHAR(1000),
            ERROR_DATE TIMESTAMP
        )
    """)

def log_error(cursor, error_message):
    """Log errors into TZDB_ERROR_LOG table."""
    try:
        cursor.execute(
            "INSERT INTO TZDB_ERROR_LOG (ERROR_MESSAGE, ERROR_DATE) VALUES (%s, %s)",
            (error_message, datetime.now())
        )
    except psycopg2.Error as e:
        print("Error logging error:", e)

def get_timezones(cursor):
    """Get list of timezones from TimezoneDB API."""
    try:
        response = requests.get(f"{BASE_URL}/list-time-zone?key={API_KEY}&format=json")
        response.raise_for_status()
        return response.json()["zones"]
    except requests.RequestException as e:
        log_error(cursor, "Error getting timezones: " + str(e))
        return []

def get_timezone_details(cursor, zone_name):
    """Get timezone details from TimezoneDB API."""
    try:
        response = requests.get(f"{BASE_URL}/get-time-zone?key={API_KEY}&format=json&zone={zone_name}")
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        log_error(cursor, f"Error getting timezone details for {zone_name}: {str(e)}")
        return {}

def populate_timezones(cursor, timezones):
    """Populate TZDB_TIMEZONES table."""
    try:
        cursor.execute("DELETE FROM TZDB_TIMEZONES")
        for timezone in timezones:
            cursor.execute("""
                INSERT INTO TZDB_TIMEZONES (COUNTRYCODE, COUNTRYNAME, ZONENAME, GMTOFFSET, IMPORT_DATE)
                VALUES (%s, %s, %s, %s, %s)
            """, (timezone["countryCode"], timezone["countryName"], timezone["zoneName"], timezone["gmtOffset"], datetime.now()))
    except psycopg2.Error as e:
        print("Error populating TZDB_TIMEZONES:", e)

def populate_zone_details(cursor, timezone_name):
    """Populate TZDB_ZONE_DETAILS table."""
    try:
        cursor.execute("""
            SELECT 1 FROM TZDB_ZONE_DETAILS 
            WHERE ZONENAME = %s
        """, (timezone_name,))
        existing_record = cursor.fetchone()
        if not existing_record:
            timezone_details = get_timezone_details(cursor, timezone_name)
            if timezone_details:
                cursor.execute("""
                    INSERT INTO TZDB_ZONE_DETAILS (COUNTRYCODE, COUNTRYNAME, ZONENAME, GMTOFFSET, DST, ZONESTART, ZONEEND, IMPORT_DATE)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (timezone_details["countryCode"], timezone_details["countryName"], timezone_details["zoneName"], timezone_details["gmtOffset"], timezone_details["dst"], timezone_details["zoneStart"], timezone_details["zoneEnd"], datetime.now()))
    except psycopg2.Error as e:
        print(f"Error populating TZDB_ZONE_DETAILS for {timezone_name}: {e}")

def main():
    try:
        connection = psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD,
            host=DB_HOST,
            port=DB_PORT
        )
        cursor = connection.cursor()

        create_tables(cursor)

        timezones = get_timezones(cursor)
        populate_timezones(cursor, timezones)

        for timezone in timezones:
            populate_zone_details(cursor, timezone["zoneName"])

        connection.commit()
    except psycopg2.Error as e:
        print("Error:", e)
    finally:
        cursor.close()
        connection.close()

if __name__ == "__main__":
    main()
